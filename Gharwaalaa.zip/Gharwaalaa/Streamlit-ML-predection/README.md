# Streamlit-ML-predection
Streamlit ML app deployed on Heroku
